function toggle(){
    const menu=document.querySelector(".menul");
    const icon=document.querySelector(".hamburger_icon");
    menu.classList.toggle("open");
    icon.classList.toggle("open");
}